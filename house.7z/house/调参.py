import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
train=pd.read_csv(r'D:\workplace\xiangmu\House Prices\train.csv')
test=pd.read_csv(r'D:\workplace\xiangmu\House Prices\test.csv')
ntrain=train.shape[0]
ntest=test.shape[0]
datas = pd.concat([train, test], ignore_index = True)
SalePrice=np.log(train.SalePrice)
train_ID = train['Id']
test_ID = test['Id']
# print(datas.info())#查看数据是否有缺失
#------------------------一、数据可视化探索--------------------
#~~~~~先看各变量之间的线性关系
# corrmat=train.corr()                     #用pandas计算相关系数
# fig,ax=plt.subplots(figsize=(12,9))
# sns.heatmap(corrmat,vmax=.8,square=True)
# plt.show()
# #选出前10个相关性最强的
# k=10
# fig1,ax1=plt.subplots(figsize=(12,12))
# cols=corrmat.nlargest(k,'SalePrice')['SalePrice'].index
# #查看10个变量的相关系数
# cols_cor = datas[cols].corr()
# # cm=np.corrcoef(datas[cols].values.T)                       #用numpy计算相关系数
# sns.set(font_scale=1.25)
# hm=sns.heatmap(cols_cor,cbar=True,annot=True,square=True,fmt='.2f',lw=1,annot_kws={'size':10},yticklabels=cols,xticklabels=cols)
# plt.show()
# #~~~~~~因变量是否服从正态分布
import scipy.stats as stats
# #绘制直方图
#
# sns.distplot(a=train.SalePrice,bins=10,fit=stats.norm,norm_hist=None,
#              kde_kws={'color': 'black', 'linestyle': '--', 'label': '核密度曲线'},
#              fit_kws={'color': 'red', 'linestyle': ':', 'label': '正态密度曲线'})
# #显示图例
# plt.legend()
# plt.show()
# #取对数符合正态分布(左偏右偏的话，取对数即可)
# sns.distplot(np.log(train.SalePrice),bins=10,fit=stats.norm,norm_hist=None,
#              kde_kws={'color': 'black', 'linestyle': '--', 'label': '核密度曲线'},
#              fit_kws={'color': 'red', 'linestyle': ':', 'label': '正态密度曲线'})
# #显示图例
# plt.legend()
# #显示图形
# plt.show()
# #~~~~~~~异常值查看
# #1.用线性相关图，散点图来查看,连续的值才会有相关性
import seaborn as sns
# sns.pairplot(
#     x_vars=['OverallQual','GrLivArea','GarageCars','GarageArea','TotRmsAbvGrd','YearBuilt','TotalBsmtSF','MasVnrArea'],
#     y_vars='SalePrice',
#     data=train#指定绘图数据集
# )
# plt.show()


#-------------------------二、数据清洗-----------------------------
#一般数据处理要将训练集和测试集分开进行，否则可能在测试集的众数与训练集的不同。
#~~~~~~~~~~异常值处理
train.drop(train[(train['OverallQual']<5) & (train['SalePrice']>200000)].index, inplace=True)
train.drop(train[(train['SalePrice']<190000) & (train['GrLivArea']>4000)].index, inplace=True)
train.drop(train[(train['YearBuilt']<1900) & (train['SalePrice']>400000)].index, inplace=True)
train.drop(train[(train['SalePrice']<200000) & (train['TotalBsmtSF']>5000)].index, inplace=True)
train.drop(train[(train['SalePrice']<200000) & (train['GarageArea']>1000)].index, inplace=True)
# import seaborn as sns
# sns.pairplot(
#     x_vars=['OverallQual','GrLivArea','GarageCars','GarageArea','TotRmsAbvGrd','YearBuilt','TotalBsmtSF'],
#     y_vars='SalePrice',
#     data=train#指定绘图数据集
# )
# plt.show()

#~~~~~~~~~~~~~~~~因变量对数变换
# train['SalePrice']=np.log(train['SalePrice'])

#~~~~~~~~~~~~~~~~~~~缺失值处理    --确实太多删掉，每一个都要处理，要不是众数替代要不就是0替代，眼部就是None替代。就是要考虑实际情况
"""
对于缺失数据的处理，通常会有以下几种做法
如果缺失的数据过多，达到80%以上，可以考虑删除该列特征
用平均值、中值、分位数、众数、随机值等替代。但是效果一般，因为等于人为增加了噪声
用插值法进行拟合
用其他变量做预测模型来算出缺失变量。效果比方法1略好。有一个根本缺陷，如果其他变量和缺失变量无关，则预测的结果无意义
最精确的做法，把变量映射到高维空间。比如性别，有男、女、缺失三种情况，则映射成3个变量：是否男、是否女、是否缺失。缺点就是计算量会加大。
除此之外，还可以用knn等模型、或基于业务的理解去填充
这里暂时先查看缺失值的分布情况，对于部分我们需要的重要变量进行缺失值处理，这部分我会放在后面根据数据类型分别处理。
"""
# print(datas.info())#查看数据是否有缺失
#删除无影响的变量
datas.drop('Id',axis=1, inplace=True)
datas.drop('Utilities',axis=1, inplace=True)
#对字符类型的数据的用none替代
str_cols= ['MiscFeature','Fence','PoolQC','Alley','FireplaceQu','GarageType','GarageFinish',"GarageQual", "GarageCond"]

for col in str_cols:
    datas[col].fillna("None", inplace=True)
del str_cols, col
#对于字符类型用众数填取无值变量
other_color=['Exterior1st','Exterior2nd','MasVnrType','BsmtQual','BsmtCond','BsmtExposure','BsmtFinType1','BsmtFinSF1',
             'BsmtFinType2','Electrical','KitchenQual','Functional','SaleType']
for col in other_color:
    datas[col].fillna(datas[col].mode()[0], inplace=True)
#对于连续型数值拿0替代
int_cols= ['MasVnrArea','BsmtFinSF2','BsmtUnfSF','TotalBsmtSF','BsmtFullBath','BsmtHalfBath','GarageYrBlt','GarageCars','GarageArea']
for col in int_cols:
    datas[col].fillna(0, inplace=True)
#***对于变量，位于同一街道的相邻的房屋往往具有相同的街区面积属性，因此LotFrontage属性的缺失值按照以下方式进行填充。
datas["LotFrontage"] =datas.groupby("Neighborhood")["LotFrontage"].transform(lambda x: x.fillna(x.median()))#以Neighborhood分组，fillna()以均值填充
#**哑变量处理
# 特征MSZoning里面有两个不同的离散值RL和RM，那么这一步将去掉MSZoning特征，并新加两个特征MSZoning_RL和MSZoning_RM,其值为0或者1
# 将数值型的Pclass转换为类别型，否则无法对其哑变量处理
datas.MSZoning = datas.MSZoning.astype('category')
# 哑变量处理
dummy = pd.get_dummies(datas[['MSZoning']])
# 水平合并Titanic数据集和哑变量的数据集
datas = pd.concat([datas,dummy], axis = 1)
# 删除原始的变量
datas.drop(['MSZoning'], inplace=True, axis = 1)
# print(datas.info())
#-------------------------三、特征工程-----------------------------
"""
类别特征不能直接输入模型，因此要对其进行编码，把它转换成数字。编码有两种方式，对于各个类别中可能存在顺序关系的，用LabelEncoder编码，对于不存在顺序关系的，用get_dummies。
"""
#转换为字符串，即类别型变量
datas['MSSubClass'] = datas['MSSubClass'].apply(str)
datas['YrSold'] = datas['YrSold'].astype(str)
datas['MoSold'] = datas['MoSold'].astype(str)
datas['OverallCond'] = datas['OverallCond'].astype(str)
#~~~~查看因变量是否倾斜以及转换为正态分布(数据的规范化处理有利于排除或者减弱数据异常的影响，从而可以提升模型效率。数据转换的方式有很多种，比较常用的有对数转换，box-cox转换等变换方式。)
"""数据的规范化处理有利于排除或者减弱数据异常的影响，从而可以提升模型效率。数据转换的方式有很多种，比较常用的有对数转换，box-cox转换等变换方式。在数据清洗-目标变量SalePrice环节， 采用了对数转换对数据进行规范化处理，这里，我们将采用box-cox转换。数据转换是针对数据变量进行的特征处理，先找出数值特征。"""
# SalePrice=train['SalePrice']、
datas.drop('SalePrice',axis=1, inplace=True)
#找到数值类特征
numeric_dtypes = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
numeric = []
for i in datas.columns:
    if datas[i].dtype in numeric_dtypes:
        numeric.append(i)
# #为所有特征做箱型图,发现数据倾斜较为严重
# sns.set_style('white')
# f, ax = plt.subplots(figsize=(8, 7))
# ax.set_xscale('log')
# ax = sns.boxplot(data=datas[numeric] , orient='h', palette='Set1')
# ax.xaxis.grid(False)
# ax.set(ylabel='Feature names')
# ax.set(xlabel='Numeric values')
# ax.set(title='Numeric Distribution of Features')
# sns.despine(trim=True, left=True)
# plt.show()
#找到倾斜的数值特征
skew_datas = datas[numeric].apply(lambda x:x.skew()).sort_values(ascending=False)
high_skew = skew_datas [skew_datas >0.15]
skew_index = list(high_skew.index)
# print('There are {} numeric features with skew>0.15'.format(high_skew.shape[0]))
skewness = pd.DataFrame({'Skew':high_skew})
#使用scipy函数boxcox1p来计算Box-Cox转换
from scipy.special import boxcox1p
from scipy.stats import boxcox_normmax
for i in skew_index:
    # print(datas[i])
    datas[i]= boxcox1p(datas[i],stats.boxcox_normmax(datas[i]+1))
# #再次查看数据倾斜程度
# sns.set_style('white')
# f,ax = plt.subplots(figsize=(8,7))
# ax.set_xscale('log')
# ax = sns.boxplot(data=datas[skew_index],orient='h',palette='Set1')
# ax.xaxis.grid(False)
# ax.set(ylabel='Feature names')
# ax.set(xlabel='Numeric values')
# ax.set(title='Numeric Distribution of Features')
# sns.despine(trim=True,left=True)
# plt.show()#发现都已经呈现正态分布
#~~~~~~~采用Lable Enconding对离散型数据进行编码(有顺序的编码)
#自定义顺序，并进行替换
datas = datas.replace({'Street': {'Pave': 1, 'Grvl': 0 },
                             'FireplaceQu': {'Ex': 5,
                                            'Gd': 4,
                                            'TA': 3,
                                            'Fa': 2,
                                            'Po': 1,
                                            'None': 0
                                            },
                             'Fence': {'GdPrv': 2,
                                       'GdWo': 2,
                                       'MnPrv': 1,
                                       'MnWw': 1,
                                       'None': 0},
                             'ExterQual': {'Ex': 5,
                                            'Gd': 4,
                                            'TA': 3,
                                            'Fa': 2,
                                            'Po': 1
                                            },
                             'ExterCond': {'Ex': 5,
                                            'Gd': 4,
                                            'TA': 3,
                                            'Fa': 2,
                                            'Po': 1
                                            },
                             'BsmtQual': {'Ex': 5,
                                            'Gd': 4,
                                            'TA': 3,
                                            'Fa': 2,
                                            'Po': 1,
                                            'None': 0},
                             'BsmtExposure': {'Gd': 3,
                                            'Av': 2,
                                            'Mn': 1,
                                            'No': 0},
                             'BsmtCond': {'Ex': 5,
                                            'Gd': 4,
                                            'TA': 3,
                                            'Fa': 2,
                                            'Po': 1},
                             'GarageQual': {'Ex': 5,
                                            'Gd': 4,
                                            'TA': 3,
                                            'Fa': 2,
                                            'Po': 1,
                                            'None': 0},
                             'GarageCond': {'Ex': 5,
                                            'Gd': 4,
                                            'TA': 3,
                                            'Fa': 2,
                                            'Po': 1,
                                            'None': 0},
                             'KitchenQual': {'Ex': 5,
                                            'Gd': 4,
                                            'TA': 3,
                                            'Fa': 2,
                                            'Po': 1},
                             'Functional': {'Typ': 0,
                                            'Min1': 1,
                                            'Min2': 1,
                                            'Mod': 2,
                                            'Maj1': 3,
                                            'Maj2': 4,
                                            'Sev': 5,
                                            'Sal': 6},
                             'CentralAir': {'Y': 1,
                                            'N': 0},
                             'PavedDrive': {'Y': 1,
                                            'P': 0,
                                            'N': 0}
                            })

#~~~~~~增加特征(增加特征主要是凭借对数据的理解进行进一步的加工， 所以我们可以基于对数据集的理解创建一些特征来帮助我们的模型。)
#基于业务理解增加特征，增加一些特征，比如总面积，就是一些其他面积的和。
#地下室面积总面积
datas['TotalBSF'] = (datas['TotalBsmtSF']+datas['1stFlrSF']+datas['2ndFlrSF']+datas['BsmtUnfSF'])
#全屋浴室加总
datas['Total_Bathrooms'] = (datas['FullBath']+(0.5*datas['HalfBath'])+datas['BsmtFullBath']+(0.5*datas['BsmtHalfBath']))
#门廊加总
datas['Total_porch_sf'] = (datas['OpenPorchSF'] + datas['3SsnPorch'] + datas['EnclosedPorch'] + datas['ScreenPorch'] + datas['WoodDeckSF'])
#车库面积加总
datas['Total_Garage'] = datas['GarageArea']+ datas['GarageCars']
#外部有关面积数据加总
datas['Outside_Area'] = datas['Total_porch_sf'] + datas['PoolArea']
#屋内全部楼层加地下室面积加总
datas['Total_sqr'] = (datas['TotalBSF'] + datas['LowQualFinSF'] + datas['1stFlrSF'] +datas['2ndFlrSF'])
#减法
#建造，售卖时间间隔
datas['YearsSinceRemodel'] = datas['YrSold'].astype(int) - datas['YearBuilt'].astype(int)
#改建，售卖时间间隔
datas['YearsSinceRemodel'] = datas['YrSold'].astype(int) - datas['YearRemodAdd'].astype(int)
#~~~~~~~对于不存在顺序关系的，用get_dummies
datas = pd.get_dummies(datas)
# print(datas.info())


#我们通过计算数值特征的对数和平方变换来创建更多的特征
def logs(res,ls):
    m = res.shape[1]
    for l in ls:
        res = res.assign(newcol=pd.Series(np.log(1.01+res[l])).values)
        res.columns.values[m] = l + '_log'
        m += 1
    return res

log_datas = ['LotFrontage','LotArea','MasVnrArea','BsmtFinSF1','BsmtFinSF2','BsmtUnfSF',
                 'TotalBsmtSF','1stFlrSF','2ndFlrSF','LowQualFinSF','GrLivArea',
                 'BsmtFullBath','BsmtHalfBath','FullBath','HalfBath','BedroomAbvGr','KitchenAbvGr',
                 'TotRmsAbvGrd','Fireplaces','GarageCars','GarageArea','WoodDeckSF','OpenPorchSF',
                 'EnclosedPorch','3SsnPorch','ScreenPorch','PoolArea','MiscVal','YearRemodAdd','TotalBSF']
datas = logs(datas,log_datas )
#通过平方转换获得新的特征
def squares(res,ls):
    m = res.shape[1]
    for l in ls:
        res = res.assign(newcol=pd.Series(res[l]*res[l]).values)
        res.columns.values[m] = l + '_sq'
        m += 1
    return res
squared_datas = ['YearRemodAdd', 'LotFrontage_log',
                    'TotalBsmtSF_log', '1stFlrSF_log', '2ndFlrSF_log', 'GrLivArea_log',
                    'GarageCars_log', 'GarageArea_log']
datas = squares(datas,squared_datas)
#~~~~~~~~特征降维，特征太多，需要特征筛选，为避免多重共线问题。下面我们会识别皮尔森相关性系数大于0.9的特征，并将这些特征删除。
#存在一些无意义的特征，需要进行降维
threshold = 0.9
#相关性矩阵
corr_matrix =datas.corr().abs()
#只选择矩阵的上半部分
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(np.bool))
# print(upper.head())
to_drop = [column for column in upper.columns if any(upper[column] > threshold)]
# print('There are %d columns to remove.' % (len(to_drop)))
#发现有63个特征需要删除
datas = datas.drop(columns = to_drop)
#然后将因变量放回,水平合并SalePrice数据集
# SalePrice=np.log(train['SalePrice'])
# datas = pd.concat([datas,SalePrice], axis = 1)
# print(datas.info)
#自此数据提前处理已完成,然后将数据拆分回训练集和测试集
clean_train = datas[:ntrain]
# clean_train = pd.concat([clean_train,np.log(train.SalePrice)], axis = 1)
clean_train = pd.concat([clean_train,SalePrice], axis = 1)
clean_test = datas[ntrain:]
# clean_test = pd.concat([clean_test,np.log(test.SalePrice)], axis = 1)
# print(clean_train.info)
# print(clean_test.info)
#---------------------------------四、数据建模---------------------------
"""
建模也就是根据所研究的问题选择恰当的算法搭建学习模型，并且基于所设定的模型评价指标，在训练过程中调整模型参数以使得模型的整体性能达到最优。
在Kaggle的比赛中优胜方案通常都会做模型集成（ensemble），模型集成会整合不同模型的预测结果，生成最终预测，集成的模型越多，效果就越好。
"""
#导包
from sklearn.linear_model import Ridge, RidgeCV, ElasticNet, LassoCV, LassoLarsCV
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from lightgbm import LGBMRegressor
from xgboost import XGBRegressor
from sklearn.svm import SVR
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import KFold, GridSearchCV, cross_val_score, train_test_split
from sklearn.metrics import mean_squared_error
#~~~~~建模之前，先划分数据集，定义交叉验证模式以及衡量指标
X = clean_train.drop(columns='SalePrice')
y = clean_train['SalePrice']
#~~~~~定义衡量指标RMSE
def rmse_cv(model):
    rmse= np.sqrt(-cross_val_score(model, X, y, scoring="neg_mean_squared_error", cv = 5))
    return(rmse)
Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, test_size=0.3, random_state=10)
# 定义交叉验证模式
kf = KFold(n_splits=10, random_state=50, shuffle=True)

#忽略警告
import warnings
def ignore_warn(*args, **kwargs):
    pass
warnings.warn = ignore_warn
#-----------------------lgb调参(用网格搜索法)------------------------
# params = {'n_estimators':[1000,2000,3000],
#           'max_depth':[6,8,10],
#           'num_leaves':[8,10,12],
#           'min_data_in_leaf':[1,3,5],
#           'learning_rate':[0.01,0.02,0.03]}
# # parameters={'n_estimators':[200,500,800,1000,2000,3000,5000,6000]} #2000
# # parameters={'n_estimators':[1200,1500,1800,2000,2200,2500,2800,3000]}#1800
# # parameters={'n_estimators':[1600, 1650, 1700, 1750, 1800, 1850, 1900, 1950]}#1950
# grid_dtreg = GridSearchCV(estimator=LGBMRegressor(**params), param_grid=params, scoring='neg_mean_squared_error', cv=5, verbose=1)
# # 模型拟合
# grid_dtreg.fit(Xtrain, ytrain)
# # 返回最佳组合的参数值
# print(grid_dtreg.best_params_)

#

from bayes_opt import BayesianOptimization
def gbdt_cv(n_estimators,max_depth,num_leaves,random_state,learning_rate,lambda_l2,lambda_l1,bagging_freq,feature_fraction,min_data_in_leaf,max_bin,bagging_fraction):
    res = cross_val_score(
        LGBMRegressor(n_estimators=int(n_estimators),max_depth=int(max_depth),max_bin=int(max_bin),num_leaves=int(num_leaves),min_data_in_leaf=int(min_data_in_leaf),
                      bagging_fraction=min(bagging_fraction,0.99999),
                      bagging_freq=int(bagging_freq),
                      feature_fraction=min(feature_fraction,0.999999),
                      lambda_l1=min(lambda_l1,0.99999),
                      lambda_l2=int(lambda_l2),
                      learning_rate=min(learning_rate,0.999),
                      random_state=int(random_state),
                      objeactive='regression'               ),
        Xtrain, ytrain, scoring='neg_mean_squared_error', cv=5
    ).mean()
    return res

gbdt_op = BayesianOptimization(
        gbdt_cv,
        {'n_estimators': (1000, 3000),
        'max_depth': (4, 15),
        # 'max_features': (0.1, 0.999),
        'num_leaves':(3,15),
        'min_data_in_leaf':(2,8),
         'max_bin':(10,30),
         'bagging_fraction':(0.1,1),
         'bagging_freq':(5,15),
         'feature_fraction':(0.1,1),
         'lambda_l1':(0.00001,1),
         'lambda_l2':(2,10),
         'learning_rate':(0.0001,1),
         'random_state':(20,80)
         }
        # 'max_depth': (6, 15)}
    )
gbdt_op.maximize()
print(gbdt_op.max)

